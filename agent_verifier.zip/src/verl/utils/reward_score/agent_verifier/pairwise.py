from typing import Dict, Any
import warnings

from agentflow.utils.tag_util import find_tags, extract_answer_tag

ALLOWED_MODEL_TAGS = {
    "1":[
        "model_a",
        "Response 1",
        "response 1",
        "A",
        "Chatbot 1",
        "Chatbot A",
        
    ],
    "2":[
        "model_b",
        "Response 2",
        "response 2",
        "B",
        "Chatbot 2",
        "Chatbot B",
    ]
}

def parse_pairwise_choice(choice_str: str) -> str:
    true_answer = extract_answer_tag(choice_str)
    if true_answer.strip() in ALLOWED_MODEL_TAGS["1"]:
        return "1"
    elif true_answer.strip() in ALLOWED_MODEL_TAGS["2"]:
        return "2"
    else:
        return "None"

def compute_pairwise_reward(
    data_source: str,
    solution_str: str,
    ground_truth: str,
    extra_info: Dict[str,Any] = None,
) -> float:
    matches = find_tags(solution_str, ["answer"])
    if matches:
        final_answer = matches[-1].body
    else:
        final_answer = None

    reward = 0
    if final_answer is None:
        reward = -1
    else:
        choice = parse_pairwise_choice(final_answer)
        parsed_ground_truth = parse_pairwise_choice(ground_truth)
        if parsed_ground_truth == "None":
            warnings.warn(f"Ground truth {ground_truth} with source {data_source} cannot be parsed for pairwise reward computation")
            reward = 0
        if choice == parsed_ground_truth:
            reward = 1
        else:
            reward = -1
    
    bonus = 0
    reward += bonus
    
    return reward
    


